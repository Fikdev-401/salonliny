<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsurePasswordChanged
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user?->must_change_password && !$request->routeIs('password.change')) {
            return redirect()
                ->route('password.change')
                ->with('warning', 'Silakan ganti password sementara Anda sebelum melanjutkan.');
        }

        return $next($request);
    }
}

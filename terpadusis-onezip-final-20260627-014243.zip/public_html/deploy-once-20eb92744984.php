<?php
$token = 'deploy20eb9274498445b8b633455c21a5eb74';
if (!hash_equals($token, (string) ($_GET['token'] ?? ''))) {
    http_response_code(404);
    exit('Not found.');
}
header('Content-Type: text/plain; charset=UTF-8');
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
set_time_limit(300);

$basePath = dirname(__DIR__);
$publicStorage = __DIR__ . '/storage';
$targetStorage = $basePath . '/storage/app/public';

echo "Terpadusis One-Zip Deploy Runner\n";
echo "================================\n\n";
echo "Base path: {$basePath}\n";
echo "PHP: " . PHP_VERSION . "\n\n";

if (!file_exists($basePath . '/.env')) {
    http_response_code(500);
    echo "ERROR: .env belum ada. Rename .env.terpadusis.example menjadi .env dan isi database.\n";
    exit;
}

try {
    require $basePath . '/vendor/autoload.php';
    $app = require $basePath . '/bootstrap/app.php';
    $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
} catch (Throwable $e) {
    http_response_code(500);
    echo "Bootstrap error: {$e->getMessage()}\n{$e->getFile()}:{$e->getLine()}\n";
    exit;
}

function runCmd(string $command, array $parameters = []): void {
    echo ">>> php artisan {$command}\n";
    try {
        $exitCode = Illuminate\Support\Facades\Artisan::call($command, $parameters);
        echo Illuminate\Support\Facades\Artisan::output();
        echo "Exit code: {$exitCode}\n\n";
        if ($exitCode !== 0) {
            throw new RuntimeException("Command failed: {$command}");
        }
    } catch (Throwable $e) {
        http_response_code(500);
        echo "ERROR saat {$command}: {$e->getMessage()}\n{$e->getFile()}:{$e->getLine()}\n";
        exit;
    }
}

runCmd('key:generate', ['--force' => true]);
runCmd('migrate', ['--force' => true]);
runCmd('db:seed', ['--class' => 'ProductionSeeder', '--force' => true]);

echo "Storage public link check:\n";
if (is_link($publicStorage) || file_exists($publicStorage)) {
    echo "[OK] public_html/storage sudah ada.\n\n";
} elseif (function_exists('symlink')) {
    try {
        symlink($targetStorage, $publicStorage);
        echo "[OK] public_html/storage symlink dibuat via symlink().\n\n";
    } catch (Throwable $e) {
        echo "[WARN] symlink gagal: {$e->getMessage()}\n";
        echo "Aplikasi tetap jalan; foto/upload publik bisa dibuat manual nanti bila perlu.\n\n";
    }
} else {
    echo "[WARN] symlink() tidak tersedia. Aplikasi tetap jalan.\n\n";
}

runCmd('route:clear');
runCmd('config:cache');
runCmd('route:cache');
runCmd('view:cache');

echo "Selesai. Catat password sementara superadmin dari output seed di atas.\n";
echo "HAPUS file runner ini dari public_html setelah deploy sukses.\n";

<?php
$token = 'finalcache337e6179751d4cc191405726';
if (!hash_equals($token, (string) ($_GET['token'] ?? ''))) {
    http_response_code(404);
    exit('Not found.');
}
header('Content-Type: text/plain; charset=UTF-8');
ini_set('display_errors', '1');
error_reporting(E_ALL);
set_time_limit(300);
$basePath = dirname(__DIR__);
echo "Terpadusis Final Cache Runner\n";
echo "=============================\n\n";
try {
    require $basePath . '/vendor/autoload.php';
    $app = require $basePath . '/bootstrap/app.php';
    $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
} catch (Throwable $e) {
    http_response_code(500);
    echo "Bootstrap error: {$e->getMessage()}\n{$e->getFile()}:{$e->getLine()}\n";
    exit;
}
function runCmd(string $command, array $parameters = []): void {
    echo ">>> php artisan {$command}\n";
    try {
        $exitCode = Illuminate\Support\Facades\Artisan::call($command, $parameters);
        echo Illuminate\Support\Facades\Artisan::output();
        echo "Exit code: {$exitCode}\n\n";
        if ($exitCode !== 0) {
            throw new RuntimeException("Command failed: {$command}");
        }
    } catch (Throwable $e) {
        http_response_code(500);
        echo "ERROR saat {$command}: {$e->getMessage()}\n{$e->getFile()}:{$e->getLine()}\n";
        exit;
    }
}
runCmd('route:clear');
runCmd('config:cache');
runCmd('route:cache');
runCmd('view:cache');
echo "Selesai. Hapus file public_html/finalize-cache-terpadusis.php setelah ini.\n";
